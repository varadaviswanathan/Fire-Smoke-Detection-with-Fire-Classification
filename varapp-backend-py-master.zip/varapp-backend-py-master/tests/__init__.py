
import django
django.setup()